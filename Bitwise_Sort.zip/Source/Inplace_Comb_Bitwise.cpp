//Bitwise Sort
//Matt Hannon March 08 07

/*
	**INCOMPLETE**
	Further optimizations at: http://graphics.stanford.edu/~seander/bithacks.html
	This entire process can be optimized to the extreme
*/

#include <windows.h>
#include <time.h>
#include <stdio.h>

#include <iostream>
#include <deque>

#define inline __forceinline
#define AMOUNT 500000

using namespace std;

int main();

template <typename T>
class cBitSort //TODO: Add support for signed values
{
	public:
		cBitSort()
		{
			Swapped = false;
			prevSection = 0;
		};
		~cBitSort()
		{


		};

		bool Sort(T *List, unsigned int Size);

		struct
		{
			unsigned int start;
			unsigned int end;
			unsigned int altend;
		} Segment;

	private:
		bool Swapped;
		unsigned int prevSection;

		void PrintBinary(T Value); //Reverse Order
		//#define SWAP(a, b) (((a) ^= (b)), ((b) ^= (a)), ((a) ^= (b)))
		inline void Swap(T *List, unsigned int Index1, unsigned int Index2)
		{	
			static T temp;
			temp = List[Index2];
			List[Index2] = List[Index1];
			List[Index1] = temp;
		};
};

template <typename T>
bool cBitSort<T>::Sort(T *List, unsigned int Size)
{
	//Not going to happen with unsigned but good to check...
	if(Size <= 0 || List == NULL)
	{
		cout << "Size of list is invalid! And/Or using a bad pointer";
		return false;
	}

	//Write basic code then advance to optimizations
	unsigned int Type_Size = sizeof(T);
	unsigned int Sorting = Size, Gap;
	bool Sortme = false;
	prevSection = Size;

	//Get rid of useless bit checks
	T MaxValue = 0;
	for(unsigned int x = 0; x < Size; x++)
	{
		if(List[x] > MaxValue)
			MaxValue = List[x];
	}
	unsigned int z = (Type_Size*8)-1;
	while(!(MaxValue & 1<<z))
		z--;

	//Init segment
	Segment.end = Size;
	Segment.altend = Size;

	//No unsigned for x because have to sort 0's and 1's too. If unsigned then x=0 :: -- = crazy #
	for(int x = z; x >= 0; x--)
	{
		for(unsigned int y = 0; y < Sorting; y++)
		{
			//MSB is set (Put biggest values at end of list) (GOAL: should be able to get it faster than radix sort)
			if(List[y] & 1<<x) // = nearly 12x slower than simple cmp (so avoid) (/ 1<<2) with remainder.. faster?
			{
				Swap(List, y, --Sorting);
				//Redo the same index because new content
				y--;
			}
		}

		Segment.start = Sorting;

		for(int bit = x-1; bit >= 0; bit--)
		{
			for(unsigned int index = Segment.start; index < Segment.end; index++)
			{
				if(List[index] & 1<<bit)
				{
					Swap(List, index, --Segment.end);
					--index;
				}
			}

			//Now 11 is ordered, do real ordering
				
			Gap = (Segment.altend - Segment.end);
			if((Segment.altend - Segment.end) > 0)
			{
				while(Gap != 1 || Swapped)
				{
					Swapped = false;
					if(Gap > 1)
					{
						Gap /= 1.3;
						if(Gap == 10 || Gap == 9)
							Gap = 11;
					}

					for(unsigned int w = Segment.end; (w+Gap) < Segment.altend; w++)
					{
						if(List[w] > List[w+Gap])
						{
							Swap(List, w, w+Gap);
							Swapped = true;
						}
					}
				}

				//Make new segment now that a few are sorted
				Segment.altend = Segment.end;
			}
		}
	}
	return true;
}

template <typename T>
void cBitSort<T>::PrintBinary(T Value)
{	
	while(Value > 0)
	{
		cout << Value%2;
		Value /= 2;
	}
	cout << "\n";
}

int main()
{
	cBitSort<int> Sort;
	int *items = new int[AMOUNT];

	srand((unsigned int)time(NULL));

	for(int x = 0; x < AMOUNT; x++)
		items[x] = rand() % 1000;

	cout << "\n\n";
	DWORD start = GetTickCount();

	Sort.Sort(&items[0], AMOUNT);
	DWORD end = GetTickCount();

	cout << endl << "Time to sort: " << end-start << " ms.";
	system("PAUSE");

	//for(int x = 0; x < AMOUNT; x++)
	//	cout << (int)items[x] << " ";


	delete []items;
	return 1;
}
