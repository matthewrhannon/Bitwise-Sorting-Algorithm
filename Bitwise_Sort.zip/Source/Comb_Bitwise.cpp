//Bitwise Sort
//Matt Hannon March 08 07

/*
	**INCOMPLETE**
	NOTE: Get rid of deques, they are slowing the processing down greatly
	Further optimizations at: http://graphics.stanford.edu/~seander/bithacks.html
	This entire process can be optimized to the extreme
*/

#include <windows.h>
#include <time.h>
#include <stdio.h>

#include <iostream>
#include <deque>

#define inline __forceinline
#define AMOUNT 500000

using namespace std;

int main();

template <typename T>
class cBitwiseSort
{
	public:
		cBitwiseSort()
		{ 
			Done = false;
		};
		~cBitwiseSort()
		{

		};

		bool Sort(deque<T> &Items);
	private:
		//functions
		void BitSort(deque<T> &Items);
		virtual void GenericSort(deque<T> &List, int Start, int End);

		inline void Swap(T &num1, T &num2)
		{
			static T temp;

			temp = num1;
			num1 = num2;
			num2 = temp;
		};

		int curBit;
		unsigned int sizeOfElement, Elements, MSB;
		T maxValue, minValue;
		bool Done;
};

template<typename T>
bool cBitwiseSort<T>::Sort(deque<T> &Items)
{
	if(Items.size() < 2)
	{
		cout << "Bad sized passed to bitwise sort\n";
		return false;
	}

	sizeOfElement = sizeof(T);
	Elements = Items.size();

	//Find max and min elements
	maxValue = 0;
	minValue = Items[0];

	for(unsigned int x = 0; x < Elements; x++)
	{
		if(Items[x] > maxValue)
			maxValue = Items[x];
	}

	//Calculate MSB of max
	MSB = (sizeOfElement*8)-1; //must account for 0
	while(!(maxValue & 1<<MSB))
		MSB--;

	BitSort(Items);

	return true;
}

template<typename T>
void cBitwiseSort<T>::BitSort(deque<T> &Items)
{
	static unsigned int numSorting = Elements, numSorted = Elements;

	for(curBit = MSB; curBit >= 0; curBit--) //must include 0
	{
		for(int index = 0; index < numSorting; index++)
		{
			//check if current bit is selected
			if(Items[index] & 1<<curBit)
			{
				//semi big value so put at end
				Swap(Items[index], Items[--numSorting]);
				//Now redo index because its a new value
				index--;
			}
		}

		//Now biggest values are at end of list, so sort em!
		if((numSorted - numSorting) > 0)
		{
			GenericSort(Items, numSorting, numSorted);
			numSorted = numSorting;
		}
	}
}
//change this up.... appeal to the inplace sorting... 
template<typename T>
void cBitwiseSort<T>::GenericSort(deque<T> &List, int Start, int End)
{
	static unsigned int Gap;

	Gap = (unsigned int)End-Start;

	//Loop until gap = 1 and zero swaps
	while(Gap != 1)
	{
		//The magic
		if(Gap > 1)
		{
			Gap = unsigned int(Gap / 1.3);
			
			//Make sure we get all turtles
			if(Gap == 10 || Gap == 9)
				Gap = 11;
		}

		for(unsigned int x = Start; (x+Gap) < End; x++)
		{
			if(List[x] > List[x+Gap])
			{
				//Swap them
				Swap(List[x], List[x+Gap]);
			}
		}
	}	
}
